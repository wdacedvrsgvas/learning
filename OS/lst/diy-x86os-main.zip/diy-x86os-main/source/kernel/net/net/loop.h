#ifndef LOOP_H
#define LOOP_H

#include "netif.h"

net_err_t loop_init(void);

#endif