#ifndef NET_PLAT_H
#define NET_PLAT_H

#include "net_err.h"
#include "sys_plat.h"

net_err_t net_plat_init(void);

#endif